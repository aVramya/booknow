﻿namespace BOOK_NOW
{
    partial class AdminRegisteration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labmsg = new System.Windows.Forms.Label();
            this.but = new System.Windows.Forms.Button();
            this.btnregister = new System.Windows.Forms.Button();
            this.txtadminemail = new System.Windows.Forms.TextBox();
            this.txtadminrepwd = new System.Windows.Forms.TextBox();
            this.txtadminpwd = new System.Windows.Forms.TextBox();
            this.txtadminname = new System.Windows.Forms.TextBox();
            this.txtadmin = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labmsgadmin = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labmsg
            // 
            this.labmsg.AutoSize = true;
            this.labmsg.Location = new System.Drawing.Point(419, 366);
            this.labmsg.Name = "labmsg";
            this.labmsg.Size = new System.Drawing.Size(0, 13);
            this.labmsg.TabIndex = 37;
            // 
            // but
            // 
            this.but.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but.Location = new System.Drawing.Point(204, 292);
            this.but.Name = "but";
            this.but.Size = new System.Drawing.Size(338, 23);
            this.but.TabIndex = 35;
            this.but.Text = "ALREADY REGISTERED ADMIN,...LOGIN";
            this.but.UseVisualStyleBackColor = true;
            this.but.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnregister
            // 
            this.btnregister.BackColor = System.Drawing.Color.Transparent;
            this.btnregister.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnregister.Location = new System.Drawing.Point(293, 245);
            this.btnregister.Name = "btnregister";
            this.btnregister.Size = new System.Drawing.Size(151, 26);
            this.btnregister.TabIndex = 34;
            this.btnregister.Text = "REGISTER";
            this.btnregister.UseVisualStyleBackColor = false;
            this.btnregister.Click += new System.EventHandler(this.btnregister_Click);
            // 
            // txtadminemail
            // 
            this.txtadminemail.Location = new System.Drawing.Point(350, 194);
            this.txtadminemail.Name = "txtadminemail";
            this.txtadminemail.Size = new System.Drawing.Size(192, 20);
            this.txtadminemail.TabIndex = 30;
            // 
            // txtadminrepwd
            // 
            this.txtadminrepwd.Location = new System.Drawing.Point(350, 154);
            this.txtadminrepwd.Name = "txtadminrepwd";
            this.txtadminrepwd.Size = new System.Drawing.Size(192, 20);
            this.txtadminrepwd.TabIndex = 29;
            this.txtadminrepwd.Leave += new System.EventHandler(this.txtadminrepwd_Leave);
            // 
            // txtadminpwd
            // 
            this.txtadminpwd.Location = new System.Drawing.Point(350, 110);
            this.txtadminpwd.Name = "txtadminpwd";
            this.txtadminpwd.Size = new System.Drawing.Size(192, 20);
            this.txtadminpwd.TabIndex = 28;
            // 
            // txtadminname
            // 
            this.txtadminname.Location = new System.Drawing.Point(350, 68);
            this.txtadminname.Name = "txtadminname";
            this.txtadminname.Size = new System.Drawing.Size(192, 20);
            this.txtadminname.TabIndex = 27;
            // 
            // txtadmin
            // 
            this.txtadmin.Location = new System.Drawing.Point(350, 25);
            this.txtadmin.Name = "txtadmin";
            this.txtadmin.Size = new System.Drawing.Size(192, 20);
            this.txtadmin.TabIndex = 26;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(224, 197);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 16);
            this.label5.TabIndex = 23;
            this.label5.Text = "ADMINEMAIL";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(214, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 16);
            this.label4.TabIndex = 22;
            this.label4.Text = "REPASSWORD";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(187, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(143, 16);
            this.label3.TabIndex = 21;
            this.label3.Text = "ADMINPASSWORD";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(224, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 16);
            this.label2.TabIndex = 20;
            this.label2.Text = "ADMINNAME";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(234, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 16);
            this.label1.TabIndex = 19;
            this.label1.Text = "ADMINID";
            // 
            // labmsgadmin
            // 
            this.labmsgadmin.AutoSize = true;
            this.labmsgadmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labmsgadmin.Location = new System.Drawing.Point(314, 363);
            this.labmsgadmin.Name = "labmsgadmin";
            this.labmsgadmin.Size = new System.Drawing.Size(0, 16);
            this.labmsgadmin.TabIndex = 38;
            // 
            // AdminRegisteration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labmsgadmin);
            this.Controls.Add(this.labmsg);
            this.Controls.Add(this.but);
            this.Controls.Add(this.btnregister);
            this.Controls.Add(this.txtadminemail);
            this.Controls.Add(this.txtadminrepwd);
            this.Controls.Add(this.txtadminpwd);
            this.Controls.Add(this.txtadminname);
            this.Controls.Add(this.txtadmin);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AdminRegisteration";
            this.Text = "AdminRegisteration";
            this.Load += new System.EventHandler(this.AdminRegisteration_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labmsg;
        private System.Windows.Forms.Button but;
        private System.Windows.Forms.Button btnregister;
        private System.Windows.Forms.TextBox txtadminemail;
        private System.Windows.Forms.TextBox txtadminrepwd;
        private System.Windows.Forms.TextBox txtadminpwd;
        private System.Windows.Forms.TextBox txtadminname;
        private System.Windows.Forms.TextBox txtadmin;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labmsgadmin;
    }
}