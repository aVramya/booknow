﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOOK_NOW
{
    public partial class Book_now1 : Form

    {

        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\ProjectsV13;Initial Catalog=USERS;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        public Book_now1()
        {
            InitializeComponent();
        }

        private void Book_now1_Load(object sender, EventArgs e)
        {
            moviedetails();
        }

        private void button22_Click(object sender, EventArgs e)
        {
            try
            {


                con.Open();
                SqlCommand cmd = new SqlCommand(" INSERT INTO USERS (MOVIELIST,USERNAME,CONTACT,SEAT,DOB,PAYMENT ) VALUES ( '" + txtselect1.Text.ToString().Trim().Replace("'", "''") + "','" + txtname1.Text.ToString().Trim().Replace("'", "''") + "','" + txtcontact1.Text.ToString().Trim().Replace("'", "''") + "','" + txtseat1.Text.ToString().Trim().Replace("'", "''") + "','" + txtdate1.Value.ToString("yyyy-MM-dd") + "','" + txtcharges1.Text.ToString().Trim().Replace("'", "''") + "')", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Seat Booked sucessfully");
                con.Close();
                //booktable();
                txtselect1.Text = "";
                txtname1.Text = "";
                txtcontact1.Text = "";
                txtseat1.Text = "";
                txtcharges1.Text = "";
            }
            catch (Exception ob)
            {
                MessageBox.Show("Please enter valid details" +ob.Message);
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {


            txtselect1.Text = "";
            txtname1.Text = "";
            txtcontact1.Text = "";
            txtseat1.Text = "";
            txtcharges1.Text = "";
        }

        private void txtselect1_SelectedIndexChanged(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from TopMovies where  Movie_Name='" + txtselect1.SelectedItem.ToString() + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                txtcharges1.Text = dr["price"].ToString();
            }
            con.Close();
        
    }
        public void moviedetails()
        {
            txtselect1.Items.Clear();
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select Movie_Name from TopMovies";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                txtselect1.Items.Add(dr["Movie_Name"].ToString());
            }
            con.Close();

        }

        private void txtseat1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
                if (txtseat1.SelectedItem.ToString() == "Front Area")
                {
                    txtcharges1.Text = Convert.ToString((Decimal.Parse(txtcharges1.Text) - 80));
                }
                else if (txtseat1.SelectedItem.ToString() == "Back Area ")
                {
                    txtcharges1.Text = Convert.ToString((Decimal.Parse(txtcharges1.Text) - 60));
                }
                else if (txtseat1.SelectedItem.ToString() == "Corner ")
                {
                    txtcharges1.Text = Convert.ToString((Decimal.Parse(txtcharges1.Text) - 30));
                }
            }

        private void button33_Click(object sender, EventArgs e)
        {
            HOMEPAGE H = new HOMEPAGE();
            H.Show();
            this.Hide();
        }
    }
    }

