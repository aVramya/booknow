﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOOK_NOW
{
    public partial class BOOKING_HISTORY : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\ProjectsV13;Initial Catalog=USERS;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        public BOOKING_HISTORY()
        {
            InitializeComponent();
            userdetails();
        }
        private void userdetails()
        {
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(" select MOVIELIST,USERNAME,CONTACT,SEAT,DOB,PAYMENT from USERS", conn);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds, "ss");
               dataGridView1.DataSource = ds.Tables["ss"];
                conn.Close();

            }
            catch (Exception ob)
            {
                MessageBox.Show("no record found" + ob.Message);
            }
        }
        private void VIEW_PROFILE_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            HOMEPAGE H = new HOMEPAGE();
            H.Show();
            this.Hide();
        }
    }
}
