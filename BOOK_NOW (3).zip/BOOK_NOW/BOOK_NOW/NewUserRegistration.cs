﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOOK_NOW
{
    public partial class NewUserRegistration : Form
    {

        public NewUserRegistration()
        {
            InitializeComponent();
        }

        private void NewUserRegistration_Load(object sender, EventArgs e)
        {

        }

        private void btnregister_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\ProjectsV13;Initial Catalog=USERS;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            string sqlquery = "insert into  [dbo].[OnlineUser] values (@uid,@uname,@upwd,@urepwd,@gender,@email,@location)";
            conn.Open();
            SqlCommand sqlcomm = new SqlCommand(sqlquery, conn);
            string gender = radmale.Checked ? "M" : "F";
            sqlcomm.Parameters.AddWithValue("@uid", txtuid.Text);
            sqlcomm.Parameters.AddWithValue("@uname", txtuname.Text);
            sqlcomm.Parameters.AddWithValue("@upwd", txtpwd.Text);
            sqlcomm.Parameters.AddWithValue("@urepwd", txtrepwd.Text);
            sqlcomm.Parameters.AddWithValue("@email", txtemail.Text);
            sqlcomm.Parameters.AddWithValue("@gender", gender);
            sqlcomm.Parameters.AddWithValue("@location", comboBox1.Text);
            sqlcomm.ExecuteNonQuery();
            labmsg.Text = "user" + txtuname.Text + "is successfully registered";
          //  linklogin.Visible = true;
            conn.Close();
        }

       
        

        private void button1_Click(object sender, EventArgs e)
        {
            LoginForm ob = new LoginForm();
            ob.Show();
            this.Hide();
        }

        private void txtrepwd_Leave(object sender, EventArgs e)
        {
            if (txtpwd.Text != txtrepwd.Text)
            {
                MessageBox.Show("password is not matching");
                txtrepwd.Focus();
                return;
            }
        }

        private void linklogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }
    }
}
