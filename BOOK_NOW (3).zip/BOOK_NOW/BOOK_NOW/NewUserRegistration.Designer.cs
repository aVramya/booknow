﻿namespace BOOK_NOW
{
    partial class NewUserRegistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NewUserRegistration));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtuid = new System.Windows.Forms.TextBox();
            this.txtuname = new System.Windows.Forms.TextBox();
            this.txtpwd = new System.Windows.Forms.TextBox();
            this.txtrepwd = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.radmale = new System.Windows.Forms.RadioButton();
            this.radfemale = new System.Windows.Forms.RadioButton();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.btnregister = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.labmsg = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(192, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "USERID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(182, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "USERNAME";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(180, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "PASSWORD";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(172, 164);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "REPASSWORD";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(206, 207);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "EMAIL";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(192, 241);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "GENDER";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(192, 284);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "LOCATION";
            // 
            // txtuid
            // 
            this.txtuid.Location = new System.Drawing.Point(308, 31);
            this.txtuid.Name = "txtuid";
            this.txtuid.Size = new System.Drawing.Size(192, 20);
            this.txtuid.TabIndex = 7;
            // 
            // txtuname
            // 
            this.txtuname.Location = new System.Drawing.Point(308, 74);
            this.txtuname.Name = "txtuname";
            this.txtuname.Size = new System.Drawing.Size(192, 20);
            this.txtuname.TabIndex = 8;
            // 
            // txtpwd
            // 
            this.txtpwd.Location = new System.Drawing.Point(308, 116);
            this.txtpwd.Name = "txtpwd";
            this.txtpwd.Size = new System.Drawing.Size(192, 20);
            this.txtpwd.TabIndex = 9;
            // 
            // txtrepwd
            // 
            this.txtrepwd.Location = new System.Drawing.Point(308, 160);
            this.txtrepwd.Name = "txtrepwd";
            this.txtrepwd.Size = new System.Drawing.Size(192, 20);
            this.txtrepwd.TabIndex = 10;
            this.txtrepwd.Leave += new System.EventHandler(this.txtrepwd_Leave);
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(308, 200);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(192, 20);
            this.txtemail.TabIndex = 11;
            // 
            // radmale
            // 
            this.radmale.AutoSize = true;
            this.radmale.Location = new System.Drawing.Point(308, 240);
            this.radmale.Name = "radmale";
            this.radmale.Size = new System.Drawing.Size(34, 17);
            this.radmale.TabIndex = 12;
            this.radmale.TabStop = true;
            this.radmale.Text = "M";
            this.radmale.UseVisualStyleBackColor = true;
            // 
            // radfemale
            // 
            this.radfemale.AutoSize = true;
            this.radfemale.Location = new System.Drawing.Point(377, 240);
            this.radfemale.Name = "radfemale";
            this.radfemale.Size = new System.Drawing.Size(31, 17);
            this.radfemale.TabIndex = 13;
            this.radfemale.TabStop = true;
            this.radfemale.Text = "F";
            this.radfemale.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "BANGLORE",
            "HYDRABAD",
            "PUNE",
            "HASSAN"});
            this.comboBox1.Location = new System.Drawing.Point(308, 279);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(192, 21);
            this.comboBox1.TabIndex = 14;
            // 
            // btnregister
            // 
            this.btnregister.BackColor = System.Drawing.Color.Transparent;
            this.btnregister.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnregister.Location = new System.Drawing.Point(332, 324);
            this.btnregister.Name = "btnregister";
            this.btnregister.Size = new System.Drawing.Size(151, 26);
            this.btnregister.TabIndex = 15;
            this.btnregister.Text = "REGISTER";
            this.btnregister.UseVisualStyleBackColor = false;
            this.btnregister.Click += new System.EventHandler(this.btnregister_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(257, 372);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(311, 23);
            this.button1.TabIndex = 16;
            this.button1.Text = "ALREADY REGISTERED USER,...LOGIN";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // labmsg
            // 
            this.labmsg.AutoSize = true;
            this.labmsg.Location = new System.Drawing.Point(377, 372);
            this.labmsg.Name = "labmsg";
            this.labmsg.Size = new System.Drawing.Size(0, 13);
            this.labmsg.TabIndex = 18;
            // 
            // NewUserRegistration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(730, 450);
            this.Controls.Add(this.labmsg);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnregister);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.radfemale);
            this.Controls.Add(this.radmale);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.txtrepwd);
            this.Controls.Add(this.txtpwd);
            this.Controls.Add(this.txtuname);
            this.Controls.Add(this.txtuid);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "NewUserRegistration";
            this.Text = "NewUserRegistration";
            this.Load += new System.EventHandler(this.NewUserRegistration_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtuid;
        private System.Windows.Forms.TextBox txtuname;
        private System.Windows.Forms.TextBox txtpwd;
        private System.Windows.Forms.TextBox txtrepwd;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.RadioButton radmale;
        private System.Windows.Forms.RadioButton radfemale;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button btnregister;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label labmsg;
    }
}