﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOOK_NOW
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //  Application.Run(new BOOK_NOW());
            // Application.Run(new Admin());
            // Application.Run(new Movies());
             Application.Run(new HOMEPAGE());
            // Application.Run(new NewUserRegistration());
           // Application.Run(new BOOKING_HISTORY ());

        }
    }
}
