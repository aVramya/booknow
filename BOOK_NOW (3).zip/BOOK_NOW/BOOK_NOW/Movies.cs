﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOOK_NOW
{
    public partial class Movies : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\ProjectsV13;Initial Catalog=USERS;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        public Movies()
        {
            InitializeComponent();
            TopMovie();
            UpComingMovies();
        }

        private void Movies_Load(object sender, EventArgs e)
        {

        }
        private void TopMovie()
        {
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(" select Movie_Name  from TopMovies", conn);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds, "ss");
                 dataGridView12.DataSource = ds.Tables["ss"];
                conn.Close();

            }
            catch (Exception ob)
            {
                MessageBox.Show("no record found" +ob.Message);
            }
        }
        private void UpComingMovies()
        {
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(" select MovieName from UpComingMovies", conn);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds, "ss");
                 dataGridView2.DataSource = ds.Tables["ss"];
                conn.Close();

            }
            catch (Exception ob)
            {
                MessageBox.Show("no record found" +ob.Message);
            }
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            HOMEPAGE H = new HOMEPAGE();
            H.Show();
            this.Hide();
        }
    }
}
