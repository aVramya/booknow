﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOOK_NOW
{
    public partial class ADMIN_Login : Form
    {
        public ADMIN_Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Admin a = new Admin();
            a.Show();
            this.Hide();

            SqlConnection sqlconn = new SqlConnection(@"Data Source=(localdb)\ProjectsV13;Initial Catalog=USERS;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            string sqlquery = "select * from  [dbo].[OnlineUser] where uname=@uname and upwd=@upwd";
            sqlconn.Open();
            SqlCommand sqlcomm = new SqlCommand(sqlquery, sqlconn);
            sqlcomm.Parameters.AddWithValue("@uname", txtadmin.Text);
            sqlcomm.Parameters.AddWithValue("@upwd", txtpwd.Text);
            SqlDataAdapter sda = new SqlDataAdapter(sqlcomm);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            sqlcomm.ExecuteNonQuery();
            if (dt.Rows.Count > 0)
            {
                
                Admin N = new Admin();
                N.Show();
                this.Hide();

            }
           
            txtadmin.Text = "";
            txtpwd.Text = "";

            sqlconn.Close();
        }

        private void ADMIN_Login_Load(object sender, EventArgs e)
        {

        }
    }
    }

