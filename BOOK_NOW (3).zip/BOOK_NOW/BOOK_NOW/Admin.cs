﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOOK_NOW
{
    public partial class Admin : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\ProjectsV13;Initial Catalog=USERS;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        public Admin()
        {
            InitializeComponent();
            TopMovie();
            UpComingMovies();


        }
        private void TopMovie()
        {
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(" select * from TopMovies",conn);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds,"ss");
                dataGridView1.DataSource = ds.Tables["ss"];
                conn.Close();

            }
            catch(Exception )
            {
                MessageBox.Show("no record found");
            }
        }
        private void UpComingMovies()
        {
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(" select * from UpComingMovies", conn);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds,"ss");
                dataGridView2.DataSource = ds.Tables["ss"];
                conn.Close();

            }
            catch (Exception)
            {
                MessageBox.Show("no record found");
            }
        }
        private void Admin_Load(object sender, EventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(" insert into TopMovies (Movie_Name,Price)values ( '" + txtmoviename.Text.ToString().Trim().Replace("'", "''") + "','" + txtprice.Text.ToString().Trim().Replace("'", "''") + "')", conn);

               cmd.ExecuteNonQuery();
                MessageBox.Show("New Movie Added");
                conn.Close();
                TopMovie();
                txtmoviename.Text = "";
                txtprice.Text = "";

            }
            catch (Exception ob)
            {
                MessageBox.Show("please check again"+ ob.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM movie WHERE movie_name='" + txtmoviename.Text + "'", conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Removed movie  sucessfully");
                    conn.Close();
                    TopMovie();
                    txtmoviename.Text = "";
                    txtprice.Text = "";
                }
                catch (Exception)
                {
                    MessageBox.Show("try again");
                }
            }

        private void btnupadd_Click(object sender, EventArgs e)
        {
            
                try
                {

                    conn.Open();
                    SqlCommand cmd = new SqlCommand(" INSERT INTO UpComingMovies (MovieName,ReleaseDate) VALUES ( '" + txtupmoviename.Text.ToString().Trim().Replace("'", "''") + "','" + dobmoviedate.Value.ToString("yyyy-MM-dd") + "')", conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("New Movie Added");
                    conn.Close();
                    UpComingMovies();
                    txtupmoviename.Text = "";


                }
                catch (Exception ob1)
                {
                    MessageBox.Show("please check again" + ob1.Message);
                }
            }

        private void btndelete2_Click(object sender, EventArgs e)
        {
               try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM UpComingMovies WHERE MovieName='" + txtupmoviename.Text + "'", conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Removed movie  sucessfully");
                    conn.Close();

                    txtupmoviename.Text = "";
                     UpComingMovies();
                }
                catch (Exception)
                {
                    MessageBox.Show("try again");
                }
            }

        private void btnexit_Click(object sender, EventArgs e)
        {
            HOMEPAGE H = new HOMEPAGE();
            H.Show();
            this.Hide();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.RowCount > 0)
            {
                txtmoviename.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                txtprice.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();

            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView2.RowCount > 0)
            {
                txtupmoviename.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();
              dobmoviedate.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString();

            }
        }

        

        private void btnnext_Click(object sender, EventArgs e)
        {

            Movies m = new Movies();
            m.Show();
            this.Hide();
        }
    }
    }
    