﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOOK_NOW
{
    public partial class AdminRegisteration : Form
    {
        public AdminRegisteration()
        {
            InitializeComponent();
        }

        private void btnregister_Click(object sender, EventArgs e)
        {
            
            SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\ProjectsV13;Initial Catalog=USERS;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            string sqlquery = "insert into  [dbo].[OnlineAdmin] values (@adminid,@adminname,@adminpwd,@adminrepwd,@adminemail)";
            conn.Open();
            SqlCommand sqlcomm = new SqlCommand(sqlquery, conn);
          
            sqlcomm.Parameters.AddWithValue("@adminid", txtadmin.Text);
            sqlcomm.Parameters.AddWithValue("@adminname", txtadminname.Text);
            sqlcomm.Parameters.AddWithValue("@adminpwd", txtadminpwd.Text);
            sqlcomm.Parameters.AddWithValue("@adminrepwd", txtadminrepwd.Text);
            sqlcomm.Parameters.AddWithValue("@adminemail", txtadminemail.Text);
            
            sqlcomm.ExecuteNonQuery();
            labmsgadmin.Text = "Admin" + txtadminname.Text + "is successfully registered";
         
            conn.Close();
        }

        private void AdminRegisteration_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ADMIN_Login a = new ADMIN_Login();
            a.Show();
            this.Hide();
        }

        private void txtadminrepwd_Leave(object sender, EventArgs e)
        {
            if( txtadminpwd.Text != txtadminrepwd.Text)
            {
                MessageBox.Show("password is not matching");
                txtadminrepwd.Focus();
                return;
            }
        }
    }
}
