﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOOK_NOW
{
    public partial class LoginForm : Form
    {

        public LoginForm()
        {
            InitializeComponent();
        }
       // public static string welcomeuser = "";
        private void btnsubmit_Click(object sender, EventArgs e)
        {

            SqlConnection sqlconn = new SqlConnection(@"Data Source=(localdb)\ProjectsV13;Initial Catalog=USERS;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        
        string sqlquery = "select * from  [dbo].[OnlineUser] where uname=@uname and upwd=@upwd";
        sqlconn.Open();
            SqlCommand sqlcomm = new SqlCommand(sqlquery, sqlconn);
        sqlcomm.Parameters.AddWithValue("@uname", txtuname.Text);
            sqlcomm.Parameters.AddWithValue("@upwd", txtpwd.Text);
            SqlDataAdapter sda = new SqlDataAdapter(sqlcomm);
        DataTable dt = new DataTable();
        sda.Fill(dt);
            sqlcomm.ExecuteNonQuery();
            if(dt.Rows.Count>0)
            {
               // welcomeuser = txtuname.Text;
                Book_now1 N = new Book_now1();
        N.Show();
                this.Hide();

    }
            else
            {
                MessageBox.Show("invalid username and password");
            }
txtuname.Text = "";
            txtpwd.Text = "";
                
            sqlconn.Close();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

      //  private void btnlogin_Click(object sender, EventArgs e)
//{
       //    Book_now1 n = new Book_now1();
        //    n.Show();
//this.Hide();
        //}
    }
    }

