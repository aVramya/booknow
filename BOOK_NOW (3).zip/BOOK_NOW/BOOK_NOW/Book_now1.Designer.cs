﻿namespace BOOK_NOW
{
    partial class Book_now1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Book_now1));
            this.txtcharges1 = new System.Windows.Forms.TextBox();
            this.txtselect1 = new System.Windows.Forms.ComboBox();
            this.txtseat1 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtdate1 = new System.Windows.Forms.DateTimePicker();
            this.txtcontact1 = new System.Windows.Forms.NumericUpDown();
            this.txtname1 = new System.Windows.Forms.TextBox();
            this.button33 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.txtcontact1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtcharges1
            // 
            this.txtcharges1.Location = new System.Drawing.Point(355, 324);
            this.txtcharges1.Name = "txtcharges1";
            this.txtcharges1.Size = new System.Drawing.Size(190, 20);
            this.txtcharges1.TabIndex = 33;
            // 
            // txtselect1
            // 
            this.txtselect1.FormattingEnabled = true;
            this.txtselect1.Items.AddRange(new object[] {
            "IRON MAN",
            "SPIDER MAN"});
            this.txtselect1.Location = new System.Drawing.Point(355, 126);
            this.txtselect1.Name = "txtselect1";
            this.txtselect1.Size = new System.Drawing.Size(190, 21);
            this.txtselect1.TabIndex = 32;
            this.txtselect1.SelectedIndexChanged += new System.EventHandler(this.txtselect1_SelectedIndexChanged);
            // 
            // txtseat1
            // 
            this.txtseat1.FormattingEnabled = true;
            this.txtseat1.Items.AddRange(new object[] {
            "Front Area",
            "Back Area",
            "Corner"});
            this.txtseat1.Location = new System.Drawing.Point(355, 249);
            this.txtseat1.Name = "txtseat1";
            this.txtseat1.Size = new System.Drawing.Size(190, 21);
            this.txtseat1.TabIndex = 31;
            this.txtseat1.SelectedIndexChanged += new System.EventHandler(this.txtseat1_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(174, 254);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 16);
            this.label7.TabIndex = 30;
            this.label7.Text = "SELECT SEAT";
            // 
            // txtdate1
            // 
            this.txtdate1.Location = new System.Drawing.Point(355, 290);
            this.txtdate1.Name = "txtdate1";
            this.txtdate1.Size = new System.Drawing.Size(190, 20);
            this.txtdate1.TabIndex = 29;
            // 
            // txtcontact1
            // 
            this.txtcontact1.Location = new System.Drawing.Point(355, 208);
            this.txtcontact1.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.txtcontact1.Name = "txtcontact1";
            this.txtcontact1.Size = new System.Drawing.Size(190, 20);
            this.txtcontact1.TabIndex = 28;
            // 
            // txtname1
            // 
            this.txtname1.Location = new System.Drawing.Point(355, 167);
            this.txtname1.Name = "txtname1";
            this.txtname1.Size = new System.Drawing.Size(190, 20);
            this.txtname1.TabIndex = 27;
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.Color.Transparent;
            this.button33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button33.Location = new System.Drawing.Point(528, 391);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(115, 23);
            this.button33.TabIndex = 26;
            this.button33.Text = "HOME PAGE";
            this.button33.UseVisualStyleBackColor = false;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.Transparent;
            this.button22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.Location = new System.Drawing.Point(399, 391);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(109, 23);
            this.button22.TabIndex = 25;
            this.button22.Text = "BOOK NOW";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Transparent;
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.Location = new System.Drawing.Point(295, 391);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 23);
            this.button11.TabIndex = 24;
            this.button11.Text = "RESET";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(171, 328);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(142, 16);
            this.label6.TabIndex = 23;
            this.label6.Text = "BOOKING CHARGE";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(176, 294);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 16);
            this.label5.TabIndex = 22;
            this.label5.Text = "SELECT DATE";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(171, 212);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 16);
            this.label4.TabIndex = 21;
            this.label4.Text = "CONTACT NO.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(174, 171);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 16);
            this.label3.TabIndex = 20;
            this.label3.Text = "YOUR NAME";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(171, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 16);
            this.label2.TabIndex = 19;
            this.label2.Text = "SELECT MOVIE";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(292, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 18);
            this.label1.TabIndex = 18;
            this.label1.Text = "BOOK MY TICKET NOW";
            // 
            // Book_now1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtcharges1);
            this.Controls.Add(this.txtselect1);
            this.Controls.Add(this.txtseat1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtdate1);
            this.Controls.Add(this.txtcontact1);
            this.Controls.Add(this.txtname1);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Book_now1";
            this.Text = "Book_now1";
            this.Load += new System.EventHandler(this.Book_now1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtcontact1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtcharges1;
        private System.Windows.Forms.ComboBox txtselect1;
        private System.Windows.Forms.ComboBox txtseat1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker txtdate1;
        private System.Windows.Forms.NumericUpDown txtcontact1;
        private System.Windows.Forms.TextBox txtname1;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}