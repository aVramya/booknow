﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOOK_NOW
{
    public partial class FeedBack : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\ProjectsV13;Initial Catalog=USERS;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        public FeedBack()
        {
            InitializeComponent();
        }

        private void FeedBack_Load(object sender, EventArgs e)
        {

        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            try
            {


                con.Open();
                SqlCommand cmd = new SqlCommand(" INSERT INTO Feeback (username,comment,rating ) VALUES ( '" + txtusername.Text.ToString().Trim().Replace("'", "''") + "','" + txtcomment.Text.ToString().Trim().Replace("'", "''")+"','" + txtrating.Text.ToString().Trim().Replace("'", "''") + "')", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("FEEDBACK SUBMITTED SUCCESSFULLY");
                con.Close();
                //booktable();
                txtusername.Text = "";
                txtcomment.Text = "";
                txtrating.Text = "";

            }
            catch (Exception ob)
            {
                MessageBox.Show("Please enter valid details" + ob.Message);
            }
        }

        private void txtrating_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            HOMEPAGE H = new HOMEPAGE();
            H.Show();
            this.Hide();
        }
    }
    }

