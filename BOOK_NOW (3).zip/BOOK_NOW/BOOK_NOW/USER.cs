﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOK_NOW
{
    class USER
    {
            public string MovieList { get; set; }
            public string UserName { get; set; }
           
            public long UserContact { get; set; }
            public string Seat { get; set; }
            public string UserDob { get; set; }
            public int Payment { get; set; }

            public override string ToString()
            {
                string mydata = "";
                mydata += UserName.ToString() + "\n";
                mydata += MovieList.ToString() + "\n";
                mydata += UserContact.ToString() + "\n";
                mydata += Seat.ToString() + "\n";
                mydata += UserDob.ToString() + "\n";
                mydata += Payment.ToString() + "\n";
                return mydata;
            }
        }
}
